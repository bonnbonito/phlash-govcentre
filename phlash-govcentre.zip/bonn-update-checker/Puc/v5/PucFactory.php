<?php

namespace Bonn\PluginUpdateChecker\v5;

if ( !class_exists(PucFactory::class, false) ):

	class PucFactory extends \Bonn\PluginUpdateChecker\v5p0\PucFactory {
	}

endif;
